#pragma once
#include <stdint.h>
#define kBufSize  0x8000
#define kNopNumber  200000