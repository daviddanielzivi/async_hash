#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "defines.h"

static char dataBuf[kBufSize];
static uint32_t hash_result = 0;

//////////////////////////////////////////////////
static void my_hash( uint32_t size) {
    uint32_t i;
    for (i = 0; i < size; i++) {
        hash_result = hash_result + (dataBuf[i] ^ 0x55);
    }
    for (i = 0; i < kNopNumber; i++) {
        __nop();
    }

}
//////////////////////////////////////////////////
int test_sync_read(char* filename) {
    FILE* fp = NULL;
    fp = fopen(filename, "rb");
    if (!fp) {
        printf("failed to open file %s\n", filename);
    }
    if (fp) {
        while (!feof(fp)) {
            uint32_t read_number = fread(dataBuf, 1, sizeof(dataBuf), fp);
            my_hash(read_number);
        }
    }
    if (fp) {
        fclose(fp);
    }
    printf("hash result: %08x\n", hash_result);
    return 0;
 }