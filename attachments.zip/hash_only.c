#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "defines.h"

static char dataBuf[kBufSize];
static uint32_t hash_result = 0;

//////////////////////////////////////////////////
static void my_hash(uint32_t size) {
	uint32_t i;
	for (i = 0; i < size; i++) {
		hash_result = hash_result + (dataBuf[i] ^ 0x55);
	}
	for (i = 0; i < kNopNumber; i++) {
		__nop();
	}

}
//////////////////////////////////////////////////
int test_hash_only(uint32_t size) {

	for (uint32_t i = 0; i < size; i += kBufSize) {
		my_hash(kBufSize);
	}
	printf("hash only done\n");
	return 0;
}